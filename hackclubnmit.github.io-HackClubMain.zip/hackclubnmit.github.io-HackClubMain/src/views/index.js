export { default as Homepage } from "./Home/Home";
export { default as Aboutpage } from "./About/About";
export { default as Eventspage } from "./Events/Events";
export { default as Gallertpage } from "./Gallery/Gallery";
export { default as EventsHome } from "./EventsHome/EventsHome";
