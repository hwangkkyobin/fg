export const team2021_tec = [{
        id: '1',
        team: 'tech team ',
        name: 'Onkar Bharatesh',
        subtitle: 'Tech Lead',
        photo: 'onkar.jpg',
    },
    {
        id: '2',
        team: 'tech team ',
        name: 'Ayush kumar',
        photo: 'ayush.jpg',
    },
    {
        id: '3',
        team: 'tech team ',
        name: 'Kalyan',
        photo: 'guy.jpg',
    },

    {
        id: '4',
        team: 'tech team ',
        name: 'Nitish kumar',
        photo: 'nitish.jpg',
    },
];


export const team2021_des = [{
        id: '1',
        team: 'des team ',
        name: 'Aniruddha Sil',
        photo: 'anirudh.jpg',
    },
    {
        id: '2',
        team: 'des team ',
        name: 'Amaan Mohib',
        photo: 'amaan.jpg',
    },
    {
        id: '3',
        team: 'des team ',
        name: 'Mohana Sahithi P',
        photo: 'mohana.jpg',
    },
    {
        id: '4',
        team: 'des team ',
        name: 'Nancy Biyahut',
        photo: 'nancy.jpg',
    },
    {
        id: '5',
        team: 'des team ',
        name: 'Utsav Sinha',
        photo: 'utsav.jpg',
    },
    {
        id: '6',
        team: 'des team ',
        name: 'Aman Shukla',
        photo: 'guy.jpg',
    },
    {
        id: '7',
        team: 'Design team ',
        name: 'Hrishikesh Karnik',
        photo: 'guy.jpg',
    }
];

export const team2021_pr = [

    {
        id: '1',
        team: 'pr team ',
        name: 'Lasya Sistla',
        photo: 'lasya.jpg',
    },
    {
        id: '2',
        team: 'pr team ',
        name: 'Viswambhari A',
        photo: 'viswambhari.jpg',
    },
    {
        id: '3',
        team: 'pr team ',
        name: 'Shubham Prasad',
        photo: 'guy.jpg',
    },
    {
        id: '4',
        team: 'pr team ',
        name: 'Harshitha P',
        photo: 'harshita.jpg',
    },

];

export const team2021_op = [{
        id: '1',
        team: 'op team ',
        name: 'Ashutosh ',
        photo: 'guy.jpg',
    },
    {
        id: '2',
        team: 'op team ',
        name: 'Shreya Nanduri',
        photo: 'shreya.jpg',
    },
    {
        id: '3',
        team: 'op team ',
        name: 'Tejas',
        photo: 'guy.jpg',
    },
    {
        id: '4',
        team: 'op team ',
        name: 'Tripti Nayak',
        photo: 'tripti.jpg',
    },
    // {
    //     id: '5',
    //     team: 'op team ',
    //     name: 'Abhishek Kedia',
    //     photo: 'abhishekkedia.jpg',
    // },
    // {
    //     id: '6',
    //     team: 'op team ',
    //     name: 'Arpit Giri',
    //     photo: 'arpitgiri.jpg',
    // },

];
export const team2021_gop = [{
        id: '1',
        team: 'ground op team ',
        name: 'Madan',
        photo: 'madan.jpg',
    },
    {
        id: '2',
        team: 'ground op team ',
        name: 'Kanaad D S ',
        photo: 'kanaad.jpg',
    },
    {
        id: '3',
        team: 'ground op team ',
        name: 'Karthik Saini',
        photo: 'kartiksaini.jpg',
    },
    {
        id: '4',
        team: 'ground op team ',
        name: 'Ayushman',
        photo: 'ayush.jpg',
    },


];
export const team2021_sponsorship = [{
        id: '1',
        team: 'sponsorship team ',
        name: 'Anant Saxena ',
        photo: 'anantsaxsena.jpg',
    },
    {
        id: '2',
        team: 'sponsorship team ',
        name: 'Bhargav Bhat ',
        photo: 'bhargavbhat.jpg',
    },

    {
        id: '3',
        team: 'sponsorship team ',
        name: 'Saishwar Anand',
        photo: 'saishwaranand.jpg',
    },

];












// 2019 data

export const team2019_tec = [

    {
        id: '1',
        team: 'tech team ',
        name: 'Anshul',
        photo: 'anshul.jpg',
    },
    {
        id: '2',
        team: 'tech team ',
        name: 'Satvik',
        photo: 'satvik.jpg',
    },
    {
        id: '3',
        team: 'tech team ',
        name: 'Kaushal',
        photo: 'guy.jpg',
    },

];

export const team2019_des = [

    {
        id: '1',
        team: 'Design team ',
        name: 'Aniruddha Sil',
        photo: 'anirudh.jpg',
    },
    {
        id: '2',
        team: 'Design team ',
        name: 'Meghana',
        photo: 'girl.jpg',
    },
    {
        id: '3',
        team: 'Design team ',
        name: 'Sayantan',
        photo: 'guy.jpg',
    },
    {
        id: '4',
        team: 'Design team ',
        name: 'Purnima',
        photo: 'girl.jpg',
    },

];
export const team2019_pr = [

    {
        id: '1',
        team: 'PR team ',
        name: 'Harshitha P',
        photo: 'harshita.jpg',
    },
    {
        id: '2',
        team: 'PR team ',
        name: 'Alisha Ahmed',
        photo: 'alishaahmed.jpg',
    },
];


export const team2019_op = [


    {
        id: '1',
        team: 'op team ',
        name: 'Piyush Aneja',
        photo: 'piyushaneja.jpg',
    },
    {
        id: '2',
        team: 'op team',
        name: 'Soumya sri P',
        photo: 'girl.jpg',
    },
    {
        id: '3',
        team: 'op team ',
        name: 'Madan ',
        photo: 'guy.jpg',
    },

];


export const team2019_gop = [

    // {
    //     id: '1',
    //     team: 'op team ',
    //     name: ' KARTIK SAINI',
    //     photo: 'kartiksaini.jpg',
    // },
    {
        id: '1',
        team: 'op team ',
        name: 'Anant Saxena',
        photo: 'anantsaxsena.jpg',
    },
    {
        id: '2',
        team: 'sponsorship team ',
        name: 'Akash ',
        photo: 'guy.jpg',
    }
];
