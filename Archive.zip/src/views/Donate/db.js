export const donarName = [
  {
    id: "1",
    name: "abc",
    link:"http:linkedin.com/1",
  },
  {
    id: "2",
    name: "abc1",
    link:"http:linkedin.com/2",
  },
  {
    id: "3",
    name: "abc2",
    link:"http:linkedin.com",
  },
  {
    id: "4",
    name: "abc3",
    link:"http:linkedin.com",
  },
  {
    id: "5",
    name: "abc4",
    link:"http:linkedin.com",
  },
];
